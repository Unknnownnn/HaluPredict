import os
import re
import json
import joblib
import numpy as np
import pandas as pd
import torch
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForSequenceClassification, AutoTokenizer

class CascadedGuardrailPipeline:
    EXPECTED_SCHEMA_VERSION = "1.1"

    def __init__(self, ensemble_file, scaler_file, metadata_file, device_str="cpu"):
        self.device = torch.device(device_str)
        with open(metadata_file, 'r') as f:
            meta = json.load(f)
        schema = meta.get("artifact_schema_version")
        if schema != self.EXPECTED_SCHEMA_VERSION:
            raise ValueError(f"Artifact schema {schema!r} is incompatible.")
        self.threshold = float(meta['threshold'])
        self.cascade_threshold = float(meta['cascade_threshold'])
        cascade_cfg = meta.get('cascade_config', {})
        self.gate_low = float(cascade_cfg.get('gate_low', 0.35))
        self.gate_high = float(cascade_cfg.get('gate_high', 0.65))
        self.tier1_weight = float(cascade_cfg.get('tier1_weight', 0.4))
        self.tier2_weight = float(cascade_cfg.get('tier2_weight', 0.6))
        self.features = meta['feature_columns']
        self.eps = meta['embedding_config']['similarity_eps']
        self.scaler = joblib.load(scaler_file)
        self.tier1_model = joblib.load(ensemble_file)
        self.embedder = SentenceTransformer(meta['embedding_config']['model_name'], device=self.device)
        tier2_name = meta['tier2_config']['model_name']
        print(f"Initializing Tier-2 NLI Verifier ({tier2_name}) on {device_str.upper()}...")
        self.tokenizer = AutoTokenizer.from_pretrained(tier2_name)
        self.tier2_model = AutoModelForSequenceClassification.from_pretrained(tier2_name).to(self.device)
        self.tier2_model.eval()
        self.id2label = {int(k): v.lower() for k, v in self.tier2_model.config.id2label.items()}

    def _normalize(self, text):
        if pd.isna(text):
            return "missing"
        text = str(text).lower().strip()
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s]', '', text, flags=re.UNICODE)
        return text if text else "empty"

    def prepare_text(self, context, prompt, response):
        ctx_clean = self._normalize(context)
        prm_clean = self._normalize(prompt)
        res_clean = self._normalize(response)
        context_missing = int(ctx_clean == "empty" or ctx_clean == "missing")
        ref_text = prm_clean if context_missing else ctx_clean
        return ref_text, res_clean, context_missing

    def compute_embeddings(self, ref_text, res_clean, prompt_text):
        embeddings = self.embedder.encode([ref_text, res_clean, prompt_text], convert_to_tensor=True, show_progress_bar=False)
        cos_sim = torch.nn.functional.cosine_similarity(embeddings[0].unsqueeze(0), embeddings[1].unsqueeze(0), eps=self.eps).item()
        prompt_cos = torch.nn.functional.cosine_similarity(embeddings[2].unsqueeze(0), embeddings[1].unsqueeze(0), eps=self.eps).item()
        return cos_sim, prompt_cos

    @staticmethod
    def _tokens(text):
        return set(re.findall(r"\b\w+\b", text))

    @classmethod
    def _lexical_overlap(cls, reference, response):
        ref_tokens, res_tokens = cls._tokens(reference), cls._tokens(response)
        if not ref_tokens or not res_tokens:
            return 0.0
        return len(ref_tokens & res_tokens) / len(ref_tokens | res_tokens)

    @staticmethod
    def _unsupported_number_ratio(reference, response):
        ref_numbers = set(re.findall(r"\b\d+\b", reference))
        resp_numbers = re.findall(r"\b\d+\b", response)
        if not resp_numbers:
            return 0.0
        unsupported = sum(1 for number in resp_numbers if number not in ref_numbers)
        return unsupported / len(resp_numbers)

    def build_features(self, cos_sim, prompt_cos, ref_text, res_clean, context_missing):
        ref_len = len(ref_text.split())
        res_len = len(res_clean.split())
        length_ratio = res_len / ref_len if ref_len > 0 else 0.0
        feature_dict = {
            "cosine_similarity": cos_sim,
            "prompt_response_cosine": prompt_cos,
            "reference_length": ref_len,
            "response_length": res_len,
            "length_ratio": length_ratio,
            "lexical_overlap": self._lexical_overlap(ref_text, res_clean),
            "unsupported_number_ratio": self._unsupported_number_ratio(ref_text, res_clean),
            "context_missing": context_missing,
        }
        feature_vector = np.array([[feature_dict[col] for col in self.features]], dtype=np.float32)
        return self.scaler.transform(feature_vector)

    def classify_tier1(self, scaled_vector):
        with torch.inference_mode():
            probs = self.tier1_model.predict_proba(scaled_vector)[0]
        return float(probs[1])

    def classify_tier2(self, premise, hypothesis):
        inputs = self.tokenizer(premise, hypothesis, return_tensors="pt", truncation=True, max_length=512).to(self.device)
        with torch.inference_mode():
            outputs = self.tier2_model(**inputs)
            probs = torch.softmax(outputs.logits, dim=-1)[0]
        entail_idx, neutral_idx, contrad_idx = None, None, None
        for idx, label in self.id2label.items():
            if "entail" in label:
                entail_idx = idx
            elif "neutral" in label:
                neutral_idx = idx
            elif "contradict" in label:
                contrad_idx = idx
        entail_prob = float(probs[entail_idx].item())
        return {
            "contradiction": float(probs[contrad_idx].item()) if contrad_idx is not None else 0.0,
            "neutral": float(probs[neutral_idx].item()) if neutral_idx is not None else 0.0,
            "entailment": entail_prob,
            "hallucination_score": 1.0 - entail_prob,
        }

    def predict(self, context, prompt, response):
        ref_text_norm, res_clean_norm, context_missing = self.prepare_text(context, prompt, response)
        prompt_text_norm = self._normalize(prompt)
        cos_sim, prompt_cos = self.compute_embeddings(ref_text_norm, res_clean_norm, prompt_text_norm)
        scaled_vector = self.build_features(cos_sim, prompt_cos, ref_text_norm, res_clean_norm, context_missing)
        tier1_score = self.classify_tier1(scaled_vector)
        if not (self.gate_low <= tier1_score <= self.gate_high):
            return int(tier1_score >= self.threshold), tier1_score, "Tier-1 (Confident Fast-Path)"
        raw_premise = prompt if (pd.isna(context) or str(context).strip() == "") else context
        tier2_score = self.classify_tier2(raw_premise, response)["hallucination_score"]
        final_score = (self.tier1_weight * tier1_score) + (self.tier2_weight * tier2_score)
        return int(final_score >= self.cascade_threshold), final_score, "Tier-2 (Cascaded NLI Ensemble)"

    def predict_streaming(self, context, prompt, response, sentence_pattern=r"(?<=[.!?])\s+"):
        sentences = [s for s in re.split(sentence_pattern, str(response).strip()) if s.strip()]
        results, prefix = [], ""
        for i, sentence in enumerate(sentences, start=1):
            prefix = f"{prefix} {sentence}".strip()
            is_hall, score, path = self.predict(context, prompt, prefix)
            results.append({
                "sentence_index": i,
                "sentence": sentence,
                "risk_score": score,
                "path": path,
                "is_hallucination": is_hall,
            })
            if is_hall:
                break
        return results
