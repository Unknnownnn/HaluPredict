import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.metrics import average_precision_score
from sklearn.model_selection import train_test_split as _tts

class _HallucinationMLP(nn.Module):
    def __init__(self, input_dim, hidden_dims=(128, 64), dropout=0.2):
        super().__init__()
        layers, prev = [], input_dim
        for hidden in hidden_dims:
            layers += [
                nn.Linear(prev, hidden),
                nn.LayerNorm(hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
            ]
            prev = hidden
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).view(-1)

class TorchMLPClassifier(ClassifierMixin, BaseEstimator):
    def __init__(self, hidden_dims=(128, 64), dropout=0.2, epochs=30,
                 batch_size=256, lr=1e-3, weight_decay=1e-4, patience=5,
                 val_fraction=0.1, device=None, random_state=42, verbose=False):
        self.hidden_dims = hidden_dims
        self.dropout = dropout
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = lr
        self.weight_decay = weight_decay
        self.patience = patience
        self.val_fraction = val_fraction
        self.device = device
        self.random_state = random_state
        self.verbose = verbose

    def _resolve_device(self):
        if self.device:
            return torch.device(self.device)
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    def _loader(self, X, y, shuffle):
        X_t = torch.from_numpy(np.asarray(X, dtype=np.float32))
        y_t = torch.from_numpy(np.asarray(y, dtype=np.float32))
        return DataLoader(
            TensorDataset(X_t, y_t),
            batch_size=self.batch_size,
            shuffle=shuffle,
            drop_last=False,
        )

    def _forward_logits(self, X):
        self.model_.eval()
        device = next(self.model_.parameters()).device
        chunks = []
        with torch.inference_mode():
            for xb, _ in self._loader(X, np.zeros(len(X)), shuffle=False):
                chunks.append(self.model_(xb.to(device)).cpu())
        return torch.cat(chunks)

    def fit(self, X, y):
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.float32).ravel()
        self.classes_ = np.unique(y)
        self.n_features_in_ = X.shape[1]
        torch.manual_seed(self.random_state)
        np.random.seed(self.random_state)
        self.device_ = self._resolve_device()
        X_tr, X_val, y_tr, y_val = _tts(X, y, test_size=self.val_fraction, random_state=self.random_state, stratify=y)
        self.model_ = _HallucinationMLP(input_dim=X.shape[1], hidden_dims=tuple(self.hidden_dims), dropout=self.dropout).to(self.device_)
        pos_weight = torch.tensor([float(len(y_tr) - y_tr.sum()) / max(float(y_tr.sum()), 1.0)], dtype=torch.float32, device=self.device_)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        optimizer = torch.optim.AdamW(self.model_.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        train_loader = self._loader(X_tr, y_tr, shuffle=True)
        best_ap, best_state, bad_epochs, epoch = -1.0, None, 0, 0
        for epoch in range(1, self.epochs + 1):
            self.model_.train()
            for xb, yb in train_loader:
                xb, yb = xb.to(self.device_), yb.to(self.device_)
                optimizer.zero_grad(set_to_none=True)
                loss = criterion(self.model_(xb), yb)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model_.parameters(), 5.0)
                optimizer.step()
            val_probs = torch.sigmoid(self._forward_logits(X_val)).numpy()
            val_ap = 0.0 if np.unique(y_val).size < 2 else float(average_precision_score(y_val, val_probs))
            if val_ap > best_ap + 1e-5:
                best_ap = val_ap
                best_state = {k: v.detach().cpu().clone() for k, v in self.model_.state_dict().items()}
                bad_epochs = 0
            else:
                bad_epochs += 1
            if bad_epochs >= self.patience:
                break
        if best_state is not None:
            self.model_.load_state_dict(best_state)
        self.model_.to("cpu")
        self.best_val_ap_ = float(best_ap)
        self.n_epochs_trained_ = epoch
        return self

    def predict_proba(self, X):
        if not hasattr(self, "model_"):
            raise RuntimeError("TorchMLPClassifier is not fitted yet.")
        probs = torch.sigmoid(self._forward_logits(np.asarray(X, dtype=np.float32))).numpy()
        return np.column_stack([1.0 - probs, probs])

    def predict(self, X):
        return self.classes_[(self.predict_proba(X)[:, 1] >= 0.5).astype(int)]
