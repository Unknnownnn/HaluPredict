import os
import re
import json
import joblib
import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from sentence_transformers import SentenceTransformer

# We must import TorchMLPClassifier so joblib can unpickle the model
from annmpl0001 import TorchMLPClassifier
from pipeclass001 import CascadedGuardrailPipeline

if __name__ == '__main__':
    print("Initializing standalone model wrapper...")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    guardrail = CascadedGuardrailPipeline(
        ensemble_file='./tier1_voting_ensemble.joblib',
        scaler_file='./guardrail_scaler.joblib',
        metadata_file='./guardrail_metadata.json',
        device_str=device
    )

    is_hall, score, path = guardrail.predict(
        context="The Eiffel Tower is in Paris.",
        prompt="Where is the Eiffel Tower?",
        response="The Eiffel Tower is in Rome."
    )
    print(f"Result -> Hallucinated? {bool(is_hall)} (Risk Score: {score:.4f}, Path: {path})")
